export interface TableBase {
    [x: string]: any;
    params: any[];
}
export declare const Message: any;
