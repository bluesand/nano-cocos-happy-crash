'use strict';

module.exports = {
    'description': '一份空白的扩展',
};
