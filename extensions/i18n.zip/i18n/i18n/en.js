'use strict';

module.exports = {
    'description': 'A blank extension',
};
